<?php

use Faker\Generator as Faker;

$factory->define(App\Delivery::class, function (Faker $faker) {
    return [
        //
        'hub' => $faker->text(50),
        'products' => $faker->text(150),
        'driver' => $faker->text(100),
        'eta' => $faker->text(20),
        'status' => $faker->text(20),
    ];
});
