<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Delivery;
use App\Http\Resources\Delivery as DeliveryResource;
use App\Http\Requests;

class DeliveryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // Get Deliveries
        $deliveries = Delivery::paginate(15);

        // Return collection of deliveries as a resource
        return DeliveryResource::collection($deliveries);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $delivery = $request->isMethod('put') ? Delivery::findOrFail
        ($request->id) : new Delivery;

        $delivery->id = $request->input('id');
        $delivery->hub = $request->input('hub');
        $delivery->products = $request->input('products');
        $delivery->driver = $request->input('driver');
        $delivery->eta = $request->input('eta');
        $delivery->status = $request->input('status');

        if($delivery->save()){
            return new DeliveryResource($delivery);
        }

    }
/*
{
    "hub": "So-Cal Hub 1",
    "products" : "Flower Power",
    "driver" : "Day One Driver",
    "eta" : "Just in Time",
    "status" : "Cloudy"
}
*/
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        // Get single delivery
        $delivery = Delivery::findOrFail($id);

        // Return the single delivery as a resource
        return new DeliveryResource($delivery);
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Get single delivery
        $delivery = Delivery::findOrFail($id);

        if($delivery->delete()) {
            return new DeliveryResource($delivery);
        }
    }
}
