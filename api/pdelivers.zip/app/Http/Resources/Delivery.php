<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class Delivery extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        //return parent::toArray($request);
        return [
            'id' => $this->id,
            'hub' => $this->hub,
            'products' => $this->products,
            'driver' => $this->driver,
            'eta' => $this->eta,
            'status' => $this->status
        ];
    }

    public function with($request){
        return [
            'version' => '1.0.0',
            'author_url' => url('http://puffydelivery.com')
        ];
    }
}
