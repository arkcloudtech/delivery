<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

// List Deliveries
Route::get('deliveries', 'DeliveryController@index');

// Show single Delivery
Route::get('delivery/{id}', 'DeliveryController@show');

// Create new Delivery
Route::post('delivery', 'DeliveryController@store');

// Update Delivery
Route::put('delivery', 'DeliveryController@store');

// Delete Delivery
Route::delete('delivery/{id}', 'DeliveryController@destroy');